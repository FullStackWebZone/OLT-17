/*
  nama : candra dwi cahyo
  umur : 17 tahun
  email : candradwicahyo18@gmail.com
*/

function imageGallery() {
  const imgBig = document.querySelectorAll('.img-big');
  const imgSmall = document.querySelectorAll('.img-small');
  imgSmall.forEach(small => {
    small.addEventListener('click', function(event) {
      imgSmall.forEach(small => small.classList.remove('active'));
      event.target.classList.add('active');
      imgBig.forEach(big => {
        if (big.getAttribute('data-filter') == small.getAttribute('data-filter')) big.src = small.src;
      });
    });
  });
}

imageGallery();
