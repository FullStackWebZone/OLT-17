
# SocialMediaIconHoverEffects

## What is Vanilla-tilt.js?

- A smooth 3D tilt javascript library forked from Tilt.js (jQuery version).

You can download it from [here](https://micku7zu.github.io/vanilla-tilt.js/).

or 

You can simply write **npm install vanilla-tilt** to download it.

Here is the [documentation](https://micku7zu.github.io/vanilla-tilt.js/) link to know more.

Click on the link to see the page live: [SocialMediaIconHoverEffects](https://jenilgajjar20.github.io/SocialMediaIconHoverEffects/)
