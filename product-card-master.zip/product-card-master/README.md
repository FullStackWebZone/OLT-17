# product-card
source code ini dibuat dengan framework css, yaitu bootstrap versi 4.

### preview

![result image](https://github.com/candradwicahyo/product-card/blob/master/assets/img/20210619_140320.jpg)
